# Belot Game Engine

Belot card game engine written in C#

Belot (Bridge-Belot or Belote) is a 32-card, trick-taking game popular in Bulgaria, France, Armenia, Croatia, Cyprus, Greece, Moldova, North Macedonia and also in Saudi Arabia.

## Build status

[![Build Status](https://nikolayit.visualstudio.com/BelotGameEngine/_apis/build/status/NikolayIT.BelotGameEngine?branchName=master)](https://nikolayit.visualstudio.com/BelotGameEngine/_build/latest?definitionId=17&branchName=master)
