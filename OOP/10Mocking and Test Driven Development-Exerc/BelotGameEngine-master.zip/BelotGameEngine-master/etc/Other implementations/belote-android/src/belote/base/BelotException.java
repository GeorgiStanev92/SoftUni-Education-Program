package belote.base;

public class BelotException extends Exception {

    /**
	 * SerialVersionUID
	 */
    private static final long serialVersionUID = 1L;

    public BelotException(String error) {
        super(error);
    }
}
