package com.karamanov.beloteGame.gui.screen.logo;

import android.content.Context;

import com.karamanov.beloteGame.gui.screen.base.BasePainter;

final class LogoPainter extends BasePainter {

    protected LogoPainter(Context context) {
        super(context);
    }
}
