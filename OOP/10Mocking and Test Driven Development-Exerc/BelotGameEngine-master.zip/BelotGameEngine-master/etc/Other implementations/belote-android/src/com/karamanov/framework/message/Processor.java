package com.karamanov.framework.message;

public interface Processor {
    
    void process();
    
}
