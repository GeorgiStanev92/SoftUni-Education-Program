# belote-android

<https://code.google.com/archive/p/belote-android/>
