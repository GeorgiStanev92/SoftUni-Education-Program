﻿using WildFarm.Contracts;

namespace WildFarm.Foods
{
    public class Seed : Food
    {
        public Seed(int quantity) 
            : base(quantity)
        {
        }
    }
}
