﻿namespace BirthdayCelebrations
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
