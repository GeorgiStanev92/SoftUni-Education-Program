﻿namespace PetStore.Models.Enumerations
{
    public enum PaymentType
    {
        Cash = 1,
        Card = 2,
    }
}
