﻿namespace PetStore.Models.Enumerations
{
    public enum Gender
    {
        Male = 1,
        Female = 2,
    }
}
