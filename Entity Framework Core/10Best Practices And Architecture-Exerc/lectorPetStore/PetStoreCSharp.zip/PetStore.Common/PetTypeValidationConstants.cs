﻿namespace PetStore.Common
{
    public static class PetTypeValidationConstants
    {
        public const int TYPE_NAME_MAX_LENGTH = 30;
    }
}
