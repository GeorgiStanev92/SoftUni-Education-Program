﻿namespace PetStore.Common
{
    public static class DatabaseConfig
    {
        public const string CONNECTION_STRING =
            @"Server=.;Database=PetStoreWebApp;Integrated Security=True;";
    }
}
