﻿namespace PetStore.Common
{
    public static class PetValidationConstants
    {
        public const int NAME_MAX_LENGTH = 50;

        public const int DESCRIPTION_MAX_LENGTH = 1000;
    }
}
