﻿namespace PetStore.Common
{
    public class ProductTypeValidationConstants
    {
        public const int NAME_MAX_LENGTH = 30;
    }
}
