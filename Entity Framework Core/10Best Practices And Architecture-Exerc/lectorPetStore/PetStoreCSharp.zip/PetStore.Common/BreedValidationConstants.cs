﻿namespace PetStore.Common
{
    public static class BreedValidationConstants
    {
        public const int NAME_MAX_LENGTH = 50;
    }
}
