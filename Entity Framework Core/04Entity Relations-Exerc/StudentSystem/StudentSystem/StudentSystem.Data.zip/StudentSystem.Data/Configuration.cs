﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string CONNECTION_STRING = @"Server=.;Database=StudentSystem;Integrated Security=True;";
    }
}
