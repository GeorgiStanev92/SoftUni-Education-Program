﻿namespace ProductShop.Dtos.Input
{
    public class CategoriesInputDto
    {
        public string Name { get; set; }
    }
}
