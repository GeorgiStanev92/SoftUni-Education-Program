﻿namespace ProductShop.Dtos.Input
{
    public class CategoryProductsDto
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
