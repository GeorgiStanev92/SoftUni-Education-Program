﻿using AutoMapper;
using ProductShop.Dtos.Input;
using ProductShop.Dtos.Output;
using ProductShop.Models;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            CreateMap<UserInputDto, User>();

            CreateMap<ProductInputDto, Product>();

            CreateMap<CategoriesInputDto, Category>();

            CreateMap<CategoryProductsDto, CategoryProduct>();

            CreateMap<Product, ProductOutputDto>()
                .ForMember(dest => dest.Seller, opt => opt.MapFrom(scr => $"{scr.Seller.FirstName} {scr.Seller.LastName}"));
        }
    }
}
