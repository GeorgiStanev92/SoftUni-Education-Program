﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Input
{
    internal class CarsInputDto
    {
    }
}
