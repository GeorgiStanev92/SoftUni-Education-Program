﻿using System;

namespace CarDealer.DTO.Output
{
    public class CustomerOutputDto
    {
        public string Name { get; set; }

        public string BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}
