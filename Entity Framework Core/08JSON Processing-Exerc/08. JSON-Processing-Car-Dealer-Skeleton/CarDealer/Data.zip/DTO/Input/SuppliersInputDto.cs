﻿namespace CarDealer.DTO.Input
{
    public class SuppliersInputDto
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
