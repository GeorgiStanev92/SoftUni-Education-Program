﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO.Input;
using CarDealer.DTO.Output;
using CarDealer.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        private static IMapper mapper;

        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            //var suppliersJsnonAsString = File.ReadAllText("../../../Datasets/suppliers.json");
            //var partsJsnonAsString = File.ReadAllText("../../../Datasets/sales.json");
            //var carsJsnonAsString = File.ReadAllText("../../../Datasets/cars.json");
           // var customersJsnonAsString = File.ReadAllText("../../../Datasets/customers.json");
            //var customersJsnonAsString = File.ReadAllText("../../../Datasets/sales.json");


            //Console.WriteLine(ImportSuppliers(context, suppliersJsnonAsString));
            //Console.WriteLine(ImportParts(context, partsJsnonAsString));
            //Console.WriteLine(ImportCars(context, carsJsnonAsString));
            //Console.WriteLine(ImportCustomers(context, customersJsnonAsString));
            //Console.WriteLine(ImportSales(context, customersJsnonAsString));

            Console.WriteLine(GetOrderedCustomers(context));
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            InitializeMapper();

             IEnumerable<SuppliersInputDto> suppliers = JsonConvert.DeserializeObject<IEnumerable<SuppliersInputDto>>(inputJson);

            IEnumerable<Supplier> mappedSuppliers = mapper.Map<IEnumerable<Supplier>>(suppliers);

            context.Suppliers.AddRange(mappedSuppliers);
            context.SaveChanges();

            return $"Successfully imported {mappedSuppliers.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            IEnumerable<Part> parts = JsonConvert.DeserializeObject<IEnumerable<Part>>(inputJson);

           foreach (var part in parts)
            {
                if (context.Suppliers.Select(x => x.Id).Contains(part.SupplierId))
                {
                    context.Parts.Add(part);
                }
            }

            context.SaveChanges();

            return $"Successfully imported {context.Parts.Count()}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            IEnumerable<Car> cars = JsonConvert.DeserializeObject<IEnumerable<Car>>(inputJson);

            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {context.Cars.Count()}.";
        }

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            IEnumerable<Customer> customers = JsonConvert.DeserializeObject<IEnumerable<Customer>>(inputJson);

            foreach (var customer in customers)
            {
                context.Customers.Add(customer);
            }

            context.SaveChanges();

            return $"Successfully imported {context.Customers.Count()}.";
        }

        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            IEnumerable<Sale> sales = JsonConvert.DeserializeObject<IEnumerable<Sale>>(inputJson);

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {context.Sales.Count()}.";
        }

        public static string GetOrderedCustomers(CarDealerContext context)
        {
            var customers = context
                .Customers
                .OrderBy(c => c.BirthDate)
                .ThenBy(c => c.IsYoungDriver)
                .Select(c => new CustomerOutputDto
                {
                    Name =c.Name,
                    BirthDate = c.BirthDate.ToString("dd//mm/yyyy", CultureInfo.InvariantCulture),
                    IsYoungDriver = c.IsYoungDriver
                });

            //var jsonSetings = new JsonSerializerSettings
            //{
            //    Formatting = Formatting.Indented
            //};

            string resultJson = JsonConvert.SerializeObject(customers);

            return resultJson;
        }

        private static void InitializeMapper()
        {
            var mapperConfiguration = new MapperConfiguration(c =>
            {
                c.AddProfile<CarDealerProfile>();
            });
            mapper = new Mapper(mapperConfiguration);
        }
    }
}