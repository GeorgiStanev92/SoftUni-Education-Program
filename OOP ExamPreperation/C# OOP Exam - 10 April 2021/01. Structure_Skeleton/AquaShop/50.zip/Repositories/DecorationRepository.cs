﻿using AquaShop.Models.Decorations.Contracts;
using AquaShop.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquaShop.Repositories
{
    public class DecorationRepository : IRepository<IDecoration>
    {
        private List<IDecoration> decoration;
        public IReadOnlyCollection<IDecoration> Models => this.decoration.AsReadOnly();

        public DecorationRepository()
        {
            this.decoration = new List<IDecoration>();
        }

        public void Add(IDecoration model) => this.decoration.Add(model);

        public IDecoration FindByType(string type) => this.decoration.FirstOrDefault(x => x.GetType().Name == type);

        public bool Remove(IDecoration model) => this.decoration.Remove(model);
    }
}
